# Se inician las Variables de Array;

nombre = []; 

stock = []; 

precio = []; 

disponible = []; 

# Creacion de functions;

def menu ():
  
  # Menu;
  
  print("\n*****MENU PRINCIPAL*****"); 
  print("1. Agregar producto"); 
  print("2. Buscar producto"); 
  print("3. Eliminar producto"); 
  print("4. Actualizar disponibilidad"); 
  print("5. Mostrar productos"); 
  print("6. Salir"); 
  
def opcion_Elegida ():
  
  # Solicitud de opcion;
  
  opcion = int(input("\nPor favor, digita una opcion: ")); 
    
  return print(f"\n¡Usted a seleccionado la opcion: {opcion}!"); 

# Function validacion nombre;  

def validacion_Nombre():
  
  nombre_Validacion = str(input("\n¡Por favor, digite su nombre: ")); 
  
  nombreFiltro = len(nombre_Validacion); 
  
  # Agregar que no se puedan tener strings vacios;
  
  if nombreFiltro >= 1 and isinstance(nombre_Validacion, str) and nombre_Validacion.isdigit() == False:
    
    print(f"\n¡Bienvenido/a: {nombre_Validacion}!"); 
  
  

#def opcion_1 (nombre, stock, precio):
  
   
  
   

# Inicio de Bucle; 

while True:
  
  menu(); 
  
  # Intenta;
  
  try:
    
    opcion_Elegida(); 
    
    validacion_Nombre(); 
    
     
    
    # Manejo de errores;
    
  except ValueError:
    
    print("\n¡ERROR!, ingrese un valor valido."); 
    